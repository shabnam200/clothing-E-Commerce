"use client";

import Link from "@/components/ui/AppLink";
import { FiArrowRight } from "react-icons/fi";
import RemoteImage from "@/components/ui/RemoteImage";
import useStage, { offsetOf, useSwipe } from "@/components/v2/ui/useStage";

const REACH = 1; // one card on each side of the centre one

// Top-level shop categories as a looping card carousel. The centre card is
// large; the side cards sit back, smaller. items: [{ key, name, href, off?, src }]
export default function V2GenderCarousel({ items, label, shopNow }) {
  const count = items.length;
  const total = count > 1 ? count * 2 : count;
  const st = useStage({ total, count, autoMs: 3000 });
  const swipe = useSwipe(st.move);

  const onKeyDown = (e) => {
    if (e.key === "ArrowRight") { e.preventDefault(); st.move(1); }
    if (e.key === "ArrowLeft") { e.preventDefault(); st.move(-1); }
  };

  return (
    <div className="v2-gcar" role="group" aria-roledescription="carousel" aria-label={label}
      onFocus={() => st.setHold(true)} onBlur={() => st.setHold(false)} onKeyDown={onKeyDown}>
      <ul className="v2-gcar__stage" aria-live="off" {...swipe}>
        {Array.from({ length: total }, (_, j) => {
          const it = items[j % count];
          const o = offsetOf(j, st.active, total);
          const a = Math.abs(o);
          const far = a > REACH;
          return (
            <li key={j} className="v2-gcard" data-far={far || undefined} data-active={o === 0 || undefined} aria-hidden={far || undefined}
              onMouseEnter={() => st.setHold(true)} onMouseLeave={() => st.setHold(false)}
              style={{ "--o": o, "--a": a, "--sg": Math.sign(o) }}>
              <Link href={it.href} className="v2-gcard__link" draggable={false} tabIndex={far ? -1 : 0}
                onClick={(e) => { if (o !== 0) { e.preventDefault(); st.move(o); } }}>
                <span className="v2-media v2-gcard__img">
                  {it.src && <RemoteImage src={it.src} alt="" sizes="(min-width: 640px) 320px, 60vw" />}
                </span>
                <span className="v2-gcard__shade" />
                <span className="v2-gcard__body">
                  <span className="v2-gcard__title v2-display">{it.name}</span>
                  <span className="v2-gcard__more">
                    {it.off && <span className="v2-gcard__off">{it.off}</span>}
                    <span className="v2-gcard__cta">{shopNow} <FiArrowRight aria-hidden="true" /></span>
                  </span>
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
