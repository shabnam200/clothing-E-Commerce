"use client";

import { useState } from "react";
import { api } from "@/services";

export default function V2Newsletter({ copy }) {
  const [state, setState] = useState("idle");
  const onSubmit = async (e) => {
    e.preventDefault();
    if (state === "sending") return;
    const form = e.currentTarget;
    const value = new FormData(form).get("email")?.toString().trim() ?? "";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) { setState("error"); return; }
    setState("sending");
    try { await api.newsletter.subscribe(value); setState("ok"); form.reset(); }
    catch { setState("error"); }
  };
  return (
    <section 
      className="v2-news-band v2-block-pad" 
      style={{ 
        position: 'relative', 
        backgroundImage: 'url("https://images.unsplash.com/photo-1441984904996-e0b6ed29ae27?q=80&w=2000&auto=format&fit=crop")', // Fashion related background
        backgroundSize: 'cover', 
        backgroundPosition: 'center', 
        backgroundAttachment: 'fixed', // Parallax effect
        color: 'var(--v2-on-image)' 
      }}
    >
      {/* Dark Overlay to make text readable */}
      <div style={{ position: 'absolute', inset: 0, backgroundColor: 'color-mix(in srgb, var(--v2-dark) 86%, transparent)', zIndex: 1 }}></div>
      
      <div className="v2-wrap v2-news v2-reveal" style={{ position: 'relative', zIndex: 2 }}>
        <h2 className="v2-display v2-h2">{copy.title}</h2>
        <p className="v2-lede">{copy.text}</p>
        <form onSubmit={onSubmit} noValidate>
          <label htmlFor="v2-email" className="sr-only">{copy.label}</label>
          <input 
            id="v2-email" name="email" type="email" autoComplete="email" 
            placeholder={copy.placeholder} aria-describedby="v2-news-msg" aria-invalid={state === "error"} 
            style={{ backgroundColor: 'color-mix(in srgb, var(--v2-on-image) 12%, transparent)', color: 'var(--v2-on-image)', border: '1px solid color-mix(in srgb, var(--v2-on-image) 28%, transparent)' }} // Adjusted input style for dark background
          />
          <button type="submit" className="v2-pill v2-pill--light" disabled={state === "sending"}>{copy.button}</button>
        </form>
        <p id="v2-news-msg" className="v2-news__msg" data-state={state} role="status">{state === "ok" ? copy.ok : state === "error" ? copy.bad : ""}</p>
      </div>
    </section>
  );
}