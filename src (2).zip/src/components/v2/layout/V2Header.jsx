import { ROUTES } from "@/config/v2";
import V2HeaderShell from "./V2HeaderShell";
import V2LangToggle from "./V2LangToggle";
import V2Logo from "@/components/v2/ui/V2Logo";
import V2PromoBar from "@/components/v2/layout/V2PromoBar";
import V2CampaignBar from "@/components/v2/campaign/V2CampaignBar";

export default function V2Header({ v2, lang, languageMode = "both", settings = {}, campaign = null, offer = null }) {
  const links = [
    { key: "home", label: v2.nav.home, href: ROUTES.home },
    // { key: "shop", label: v2.nav.shop, href: ROUTES.shop },
    { key: "categories", label: lang === "bn" ? "ক্যাটাগরি" : "Categories", href: ROUTES.categories },
    { key: "picks", label: v2.nav.picks, href: ROUTES.picks },
    { key: "lookbook", label: v2.nav.lookbook, href: ROUTES.lookbook },
    { key: "outfit", label: lang === "bn" ? "লুক বানান" : "Build a Look", href: ROUTES.outfit },
  ];

  const featureToggles = settings.featureToggles || {};
  const visibleLinks = links.filter((link) => link.key !== "outfit" || featureToggles.build_a_look !== false);
  const brandName = lang === "bn" && settings.brandNameBn ? settings.brandNameBn : settings.brandNameEn || "AVENOR";
  const toggle = languageMode === "both" ? <V2LangToggle lang={lang} label={v2.nav.lang} ariaLabel={v2.nav.langAria} /> : null;
  
  return (
    <>
      {offer ? <V2PromoBar offer={offer} /> : campaign ? <V2CampaignBar campaign={campaign} /> : <V2PromoBar />}
      <V2HeaderShell links={visibleLinks} nav={v2.nav} search={v2.search} logo={<V2Logo name={brandName} logoUrl={settings.siteLogoUrl} />} lang={toggle} showWishlist={featureToggles.wishlist !== false} showMiniCart={featureToggles.mini_cart !== false} />
    </>
  );
}
