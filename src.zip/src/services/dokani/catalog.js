﻿// AVENOR catalogue read straight from Dokani Cloud (server only). Same method names as api.catalog in services/, so
// lib/v2/catalogSource.js can use either. Products are cached in memory for CATALOG_TTL_MS.
import { relatedProducts } from "@/lib/v2/catalog";
import { assertShop, dokaniGet } from "./client";
import { CATALOG_TTL_MS, cfg } from "./config";
import { isClothingProduct, isSellable, mapProduct } from "./mapper";
import { categoryPathKey } from "@/lib/v2/categoryKey";

const PER_PAGE = 100;
let cache = { at: 0, rows: null, pending: null };
let categoryCache = { at: 0, rows: null, pending: null };
let campaignCache = { at: 0, discounts: null, pending: null };

export function clearCatalogCache() {
  cache = { at: 0, rows: null, pending: null };
  categoryCache = { at: 0, rows: null, pending: null };
  campaignCache = { at: 0, discounts: null, pending: null };
}

async function campaignDiscounts() {
  if (campaignCache.discounts && Date.now() - campaignCache.at < CATALOG_TTL_MS) return campaignCache.discounts;
  if (!campaignCache.pending) {
    campaignCache.pending = dokaniGet("/campaigns")
      .then((json) => {
        const rows = Array.isArray(json) ? json : json?.campaigns ?? json?.data ?? [];
        const discounts = new Map();
        for (const campaign of rows) {
          if (!campaign || !["1", "true"].includes(String(campaign.status).toLowerCase()) || !campaign.discount_type || !(Number(campaign.discount_value) > 0)) continue;
          let ids = campaign.product_ids;
          if (typeof ids === "string") { try { ids = JSON.parse(ids); } catch { ids = []; } }
          if (!Array.isArray(ids)) continue;
          for (const id of ids) if (!discounts.has(String(id))) discounts.set(String(id), { type: campaign.discount_type, value: Number(campaign.discount_value), campaign_id: campaign.id, campaign_title: campaign.title_en || campaign.title_bn || campaign.title || "" });
        }
        campaignCache = { at: Date.now(), discounts, pending: null };
        return discounts;
      })
      .catch(() => { campaignCache.pending = null; return campaignCache.discounts || new Map(); });
  }
  return campaignCache.pending;
}

async function withCampaignDiscount(product) {
  const discount = (await campaignDiscounts()).get(String(product.id));
  return discount ? { ...product, campaign_discount_type: discount.type, campaign_discount_value: discount.value, campaign_id: discount.campaign_id, campaign_title: discount.campaign_title } : product;
}

async function categoryRows() {
  if (categoryCache.rows && Date.now() - categoryCache.at < CATALOG_TTL_MS) return categoryCache.rows;
  if (!categoryCache.pending) {
    categoryCache.pending = dokaniGet("/shops/category")
      .then((j) => Array.isArray(j.category) ? j.category : j.category?.data ?? [])
      .then((rows) => { assertShop(rows); categoryCache = { at: Date.now(), rows, pending: null }; return rows; })
      .catch((error) => { categoryCache.pending = null; throw error; });
  }
  return categoryCache.pending;
}

function genderKey(category) {
  const value = `${category?.slug ?? ""} ${category?.name ?? ""}`.toLowerCase().replace(/[^a-z]+/g, " ").trim();
  if (/\b(women|woman|female|ladies)\b/.test(value)) return "women";
  if (/\b(men|man|male)\b/.test(value)) return "men";
  if (/\b(kids|kid|children|boys|girls)\b/.test(value)) return "kids";
  return null;
}

async function storefrontRows(rows) {
  try {
    const roots = await categoryRows();
    const byId = new Map();
    const addChildren = (children, gender) => {
      for (const child of children || []) {
        if (Number(child.status ?? 1) !== 1 || child.visible === false) continue;
        const addTree = (node, parentKey = "", parentPath = []) => {
          const key = categoryPathKey(node, parentKey);
          if (!key) return;
          const pathKeys = [...parentPath, key];
          byId.set(String(node.id), { key, gender, pathKeys });
          for (const nested of node.subs || []) if (Number(nested.status ?? 1) === 1 && nested.visible !== false) addTree(nested, key, pathKeys);
        };
        addTree(child);
      }
    };
    for (const root of roots) {
      if (Number(root.status ?? 1) !== 1 || root.visible === false) continue;
      const gender = genderKey(root);
      if (gender) addChildren(root.subs, gender);
    }
    return rows.map((product) => {
      const categoryId = product.sub_category_id || product.category_id || product.category?.id;
      const category = byId.get(String(categoryId));
      return category ? { ...product, storefront_category_key: category.key, storefront_category_path_keys: category.pathKeys, storefront_gender_key: category.gender } : product;
    });
  } catch (error) {
    console.warn("[catalog] Could not load category tree for storefront product mapping.", error?.message || error);
    return rows;
  }
}
// GET /shops/products, page by page. A plain-array answer that is shorter than PER_PAGE is the last page.
async function fetchAllRows() {
  const all = [];
  let firstId = null;
  for (let page = 1; page <= 30; page++) {
    const j = await dokaniGet("/shops/products", { per_page: PER_PAGE, page });
    const box = j.products;
    const rows = Array.isArray(box) ? box : Array.isArray(box?.data) ? box.data : [];
    if (rows.length === 0 || (page > 1 && rows[0]?.id === firstId)) break; // empty page, or the API ignores "page" and repeats itself
    firstId = firstId ?? rows[0]?.id;
    all.push(...rows);
    const hasNext = !Array.isArray(box) && (box?.links || []).some((l) => l.label === "Next" && l.url);
    if (!hasNext && rows.length < PER_PAGE) break;
  }
  return all;
}

async function rawRows() {
  if (cache.rows && Date.now() - cache.at < CATALOG_TTL_MS) return cache.rows;
  if (!cache.pending) {
    cache.pending = fetchAllRows()
      .then((rows) => { assertShop(rows); cache = { at: Date.now(), rows, pending: null }; return rows; })
      .catch((e) => { cache.pending = null; if (cache.rows && /timeout|aborted/i.test(e?.message || "")) { console.warn("[catalog] Refresh timed out; serving the last successful catalog.", e?.message || e); return cache.rows; } throw e; });
  }
  return cache.pending;
}

// Raw Dokani rows are server-only and used by checkout to resolve variant IDs
// and prices from the trusted catalogue, never from browser-submitted prices.
export async function getRawProduct(id) {
  const rows = await storefrontRows(await rawRows());
  const product = rows.find((p) => String(p.id) === String(id) && isSellable(p) && isClothingProduct(p)) ?? null;
  return product ? withCampaignDiscount(product) : null;
}

export async function listAll(_params = {}, { lang = "bn" } = {}) {
  const products = await storefrontRows(await rawRows());
  const rows = products.filter((p) => isSellable(p) && isClothingProduct(p));
  const discounts = await campaignDiscounts();
  const now = Date.now();
  return rows.map((p, i) => {
    const discount = discounts.get(String(p.id));
    const source = discount ? { ...p, campaign_discount_type: discount.type, campaign_discount_value: discount.value, campaign_id: discount.campaign_id, campaign_title: discount.campaign_title } : p;
    return mapProduct(source, lang, i, now);
  });
}
export async function list(params = {}, opts = {}) { const items = await listAll(params, opts); return { items, meta: { page: 1, limit: items.length, total: items.length, last_page: 1 } }; }
export async function get(id, opts = {}) { return (await listAll({}, opts)).find((p) => String(p.id) === String(id)) ?? null; }
export async function related(id, { limit = 4, lang = "bn" } = {}) {
  const all = await listAll({}, { lang });
  const p = all.find((x) => String(x.id) === String(id));
  return p ? relatedProducts(all, p, limit) : [];
}
export async function categories() {
  const toCategory = (c) => ({
    id: c.id,
    key: String(c.name || "").toLowerCase().replace(/[^a-z0-9]+/g, ""),
    name: c.name,
    slug: c.slug,
    image: c.image,
    image_url: c.image_url || (String(c.image || "").startsWith("http") ? c.image : null),
    shopId: c.shop_id ?? cfg().shopId ?? null,
    parent_id: c.parent_id ?? null,
    status: c.status,
    sold_quantity: Number(c.sold_quantity) || 0,
    visible: c.visible,
    subs: (c.subs || []).filter((sub) => Number(sub.status) === 1 && sub.visible !== false).map(toCategory),
  });
  return (await categoryRows())
    .filter((c) => Number(c.status) === 1 && c.visible !== false)
    .map(toCategory);
}

// For GET /api/dokani/health: a plain-language report of what the connection sees. Never contains passwords or tokens.
export async function health() {
  const out = { ok: false, shopIdInEnv: cfg().shopId || null, branchIdInEnv: cfg().branchId || null, problems: [] };
  try {
    const rows = await rawRows();
    const cats = await categories();
    const products = await storefrontRows(rows);
    const items = products.filter((p) => isSellable(p) && isClothingProduct(p)).map((p, i) => mapProduct(p, "en", i));
    out.shopIdSeenInData = cats[0]?.shopId ?? null; // the shop the login really belongs to
    out.products = { total: rows.filter((p) => isSellable(p)).length, shown: items.length, withStock: items.filter((p) => p.stock > 0).length, withPhoto: items.filter((p) => p.hasPhoto).length, withVariants: items.filter((p) => p.is_size || p.is_colour).length };
    out.categories = cats;
    out.sample = items.slice(0, 5).map((p) => ({ id: p.id, name: p.name, avenorCategory: p.category, genders: p.genders, sizes: p.sizes, price: p.price, mrp: p.mrp, stock: p.stock, tags: p.tags }));
    if (!items.length) out.problems.push("Dokani returned no sellable products. Add products in the Dokani panel (status active, not a service).");
    if (items.length && !out.products.withStock) out.problems.push("No product has stock. In Dokani add a Purchase for the products, otherwise every product shows as out of stock.");
    if (items.length && !out.products.withPhoto) out.problems.push("No product has a photo in Dokani. AVENOR shows a category picture instead until photos are uploaded.");
    if (!cfg().shopId) out.problems.push("DOKANI_SHOP_ID is not set. It is only a safety check, but set it so a wrong login is caught.");
    out.ok = true;
  } catch (e) {
    out.error = e?.message || String(e);
    out.problems.push(out.error);
  }
  return out;
}
