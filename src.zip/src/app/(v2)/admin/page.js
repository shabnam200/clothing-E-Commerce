import { notFound } from "next/navigation";
import { getAdminSession } from "@/services/dokani/adminSession";
export const dynamic = "force-dynamic";
export default async function WebsiteControlPage() {
  const admin = await getAdminSession();
  if (!admin) notFound();
  return <section className="v2-wrap" style={{ paddingBlock: "4rem", minHeight: "50vh" }}><h1>Website Control</h1><p>Signed in as {admin.name || "Administrator"}.</p><form action="/api/admin/logout" method="post"><button type="submit">Sign out</button></form></section>;
}
