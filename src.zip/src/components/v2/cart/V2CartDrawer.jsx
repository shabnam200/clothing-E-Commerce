"use client";

import { useEffect, useRef } from "react";
import Link from "@/components/ui/AppLink";
import { usePathname } from "next/navigation";
import { FiMinus, FiPlus, FiShoppingBag, FiTrash2, FiTruck, FiX } from "react-icons/fi";
import Image from "next/image";
import confetti from "canvas-confetti";
import { FREE_DELIVERY_OVER, MAX_QTY, ROUTES } from "@/config/v2";
import { useV2Store } from "@/components/v2/store/V2StoreProvider";

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])';

export default function V2CartDrawer({ copy }) {
  // FIX: catalog ke store theke niye asha holo upsell er jonno
  const { settings, catalog, ui, lines, count, subtotal, hydrated, cartOpen, closeCart, fmt, num, fill, sizeLabel, setQty, removeLine, quickAdd } = useV2Store();
  const panel = useRef(null);
  const closeBtn = useRef(null);
  const pathname = usePathname();
  
  const prevCount = useRef(count);

  useEffect(() => { closeCart(); }, [pathname, closeCart]);

  useEffect(() => {
    if (cartOpen && count > prevCount.current) {
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        zIndex: 99999
      });
    }
    prevCount.current = count;
  }, [cartOpen, count]);

  useEffect(() => {
    if (!cartOpen) return;
    const opener = document.activeElement;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const t = setTimeout(() => closeBtn.current?.focus(), 60);
    const onKey = (e) => {
      if (e.key === "Escape") { closeCart(); return; }
      if (e.key !== "Tab" || !panel.current) return;
      const els = [...panel.current.querySelectorAll(FOCUSABLE)];
      if (!els.length) return;
      const first = els[0], last = els[els.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      clearTimeout(t);
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
      if (opener instanceof HTMLElement) opener.focus();
    };
  }, [cartOpen, closeCart]);

  const shown = hydrated ? lines : [];
  const freeOver = settings?.freeDeliveryOver ?? FREE_DELIVERY_OVER;
  const left = freeOver - subtotal;
  const pct = Math.min(100, Math.round((subtotal / freeOver) * 100));

  // FIX: Upsell items toiri kora holo (je product gulo cart e nai, shegulo theke random 3ta nibe)
  const upsellItems = catalog?.filter(p => !lines.some(l => l.p.id === p.id)).slice(0, 4) || [];

  return (
    <>
      <div className="v2-overlay" data-open={cartOpen || undefined} onClick={closeCart} aria-hidden="true" />
      <aside ref={panel} className="v2-cartdrawer" data-open={cartOpen || undefined} role="dialog" aria-modal="true" aria-labelledby="v2-cartdrawer-title" inert={!cartOpen}>
        <header className="v2-cartdrawer__head">
          <h2 id="v2-cartdrawer-title">{copy.drawerTitle}{shown.length > 0 && <span> ({num(count)})</span>}</h2>
          <button ref={closeBtn} type="button" className="v2-icon-btn" aria-label={copy.close} onClick={closeCart}><FiX aria-hidden="true" /></button>
        </header>

        {shown.length === 0 ? (
          <div className="v2-cartdrawer__empty">
            <span className="v2-empty__icon"><FiShoppingBag aria-hidden="true" /></span>
            <h3 className="v2-display">{copy.emptyTitle}</h3>
            <p>{copy.emptyText}</p>
            <Link href={ROUTES.shop} className="v2-pill v2-pill--solid" onClick={closeCart}>{copy.continue}</Link>
          </div>
        ) : (
          <>
            <div className="v2-cartdrawer__ship">
              <p>{left > 0 ? fill(copy.freeLeft, { amount: fmt(left) }) : copy.freeDone}</p>
              <div className="v2-bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct}>
                <span style={{ width: `${pct}%` }} />
                <FiTruck aria-hidden="true" />
              </div>
            </div>

            <div style={{ flex: '1 1 auto', overflowY: 'auto' }}>
              <ul className="v2-cartdrawer__list">
                {shown.map((l) => (
                  <li key={l.key} className="v2-dline">
                    <Link href={ROUTES.product(l.p.id)} className="v2-dline__img" onClick={closeCart} aria-label={l.p.name}>
                      <span className="v2-media">
                        {l.p.image ? <Image src={l.p.image} alt={l.p.name} width={88} height={88} unoptimized style={{ objectFit: 'cover' }} /> : null}
                      </span>
                    </Link>
                    <div className="v2-dline__info">
                      <h3><Link href={ROUTES.product(l.p.id)} onClick={closeCart}>{l.p.name}</Link></h3>
                      <p className="v2-dline__meta">{l.size ? `${copy.size}: ${sizeLabel(l.size)}` : null}{l.size && l.color ? " · " : ""}{l.color || null}{l.size || l.color ? " · " : ""}{l.p.priceText}</p>
                      <div className="v2-dline__row">
                        <div className="v2-qty" role="group" aria-label={`${ui.qty}: ${l.p.name}`}>
                          <button type="button" aria-label={ui.decrease} disabled={l.qty <= 1} onClick={() => setQty(l.key, l.qty - 1)}><FiMinus aria-hidden="true" /></button>
                          <output aria-live="polite">{num(l.qty)}</output>
                          <button type="button" aria-label={ui.increase} disabled={l.qty >= MAX_QTY} onClick={() => setQty(l.key, l.qty + 1)}><FiPlus aria-hidden="true" /></button>
                        </div>
                        <p className="v2-dline__total">{fmt(l.lineTotal)}</p>
                        <button type="button" className="v2-icon-btn v2-dline__remove" aria-label={`${ui.remove}: ${l.p.name}`} onClick={() => removeLine(l.key)}><FiTrash2 aria-hidden="true" /></button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>

              {/* FIX: Premium Upsell Section Added Here */}
              {upsellItems.length > 0 && (
                <div style={{ padding: '24px 20px', borderTop: '1px solid var(--v2-line)', background: 'var(--v2-surface)' }}>
                  <h3 style={{ fontSize: '13px', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '16px', color: 'var(--v2-muted)', fontWeight: '600' }}>You might also like</h3>
                  <div style={{ display: 'flex', gap: '16px', overflowX: 'auto', scrollbarWidth: 'none', paddingBottom: '10px' }}>
                    {upsellItems.map(item => (
                      <div key={item.id} style={{ minWidth: '120px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        <Link href={ROUTES.product(item.id)} onClick={closeCart} style={{ display: 'block', borderRadius: '6px', overflow: 'hidden', aspectRatio: '3/4', position: 'relative' }}>
                          <Image src={item.image} alt={item.name} fill unoptimized style={{ objectFit: 'cover' }} sizes="120px" />
                        </Link>
                        <div>
                          <Link href={ROUTES.product(item.id)} onClick={closeCart} style={{ fontSize: '13px', fontWeight: '500', display: 'block', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.name}</Link>
                          <p style={{ fontSize: '13px', color: 'var(--v2-muted)', marginBottom: '8px' }}>{item.priceText}</p>
                          <button 
                            onClick={() => quickAdd(item)}
                            style={{ width: '100%', padding: '6px', fontSize: '12px', background: 'transparent', border: '1px solid var(--v2-line)', color: 'var(--v2-ink)', borderRadius: '4px', cursor: 'pointer' }}
                          >
                            + Add
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <footer className="v2-cartdrawer__foot">
              <div className="v2-cartdrawer__sub"><span>{copy.subtotal}</span><strong>{fmt(subtotal)}</strong></div>
              <p className="v2-cartdrawer__note">{copy.drawerNote}</p>
              <Link href={ROUTES.cart} className="v2-pill v2-pill--outline" onClick={closeCart}>{copy.viewCart}</Link>
              <Link href={ROUTES.checkout} className="v2-pill v2-pill--solid" onClick={closeCart}>{copy.checkout}</Link>
              <ul className="v2-cartdrawer__pay" aria-hidden="true">{copy.payments.map((p) => <li key={p}>{p}</li>)}</ul>
            </footer>
          </>
        )}
      </aside>
    </>
  );
}